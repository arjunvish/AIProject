package project

import scala.collection.mutable.PriorityQueue
import scala.collection.mutable.Set
import project.Algorithms._
import scala.io.StdIn.readInt
object Start {
	def main(args: Array[String]) = {
 
	  	val ts = Map((1, 1) -> 3, (1, 2) -> 6, (1, 3) -> 2, (2, 1) -> 4, (2, 2) -> 7, (3, 1) -> 1, (3, 2) -> 5, (3, 3) -> 8)
		val b = Board(3, ts)
		val start = BoardState(b, (2,3))
		//println(start)
		val ts2 = Map (
			(1, 1) -> 5 			, (1, 3) -> 1, (1, 4) -> 4,
			(2, 1) -> 9, (2, 2) -> 7, (2, 3) -> 3, (2, 4) -> 11,
			(3, 1) -> 6, (3, 2) -> 2, (3, 3) -> 14, (3, 4) -> 8,
			(4, 1) -> 13, (4, 2) -> 10, (4, 3) -> 15, (4, 4) -> 12
		)
		val b2 = Board(4, ts2)
		val start2 = BoardState(b2, (1, 2))
		val b12 = BoardState(Board(4, Map( (1, 1) -> 1, (1, 2) -> 10, (1, 3) -> 8, (1, 4) -> 2, (2, 1) -> 5, (2, 2) -> 14, (2, 3) -> 4, (3, 1) -> 9, (3, 2) -> 6, (3, 3) -> 3, (3, 4) -> 12, (4, 1) -> 13, (4, 2) -> 11, (4, 3) -> 7, (4, 4) -> 15)), (2, 4))
		//println(goalState(4))
		val y = IDAstar(b12, goalState(4), List(Left, Right, Up, Down), misplaced: (BoardState, BoardState) => Double)
		//for (i <- y) println(i)
		//println(y.length)
		
		var flag : Boolean = false
		var option : Int = 10
		while(!flag){
			print("Menu: \n1. A* with Manhatten distance on sample input\n2. A* with misplaced tiles on sample input\n3. A* with max-swap on sample input\n4. IDA* with Manhatten distance on sample input\n5. IDA* with misplaced tiles on sample input\n6. IDA* with max-swap on sample input\n7. Statistics from part 1 of problem\n8. Statistics from part 2 of problem.\n9. Exit\n\n")
			option = Console.readInt()
			option match{
				case 1 => {println("8-Puzzle:")
						  println("Test input:\n "+start.toString)
						  println("Goal state:\n "+goalState(3))
					      var l1 = Astar(start, goalState(3), List(Left, Right, Up, Down), manhattan)
						  for(i <- l1._1) println(i)
						  println("15-Puzzle")
						  println("Test input:\n "+start2.toString)
						  println("Goal state:\n "+goalState(4))
						  val l2 = Astar(start2, goalState(4), List(Left, Right, Up, Down), manhattan)
						  for(i <- l2._1) println(i)}
				case 2 => {println("8-Puzzle:")
						  println("Test input:\n "+start.toString)
						  println("Goal state:\n "+goalState(3))
					      var l1 = Astar(start, goalState(3), List(Left, Right, Up, Down), misplaced)
						  for(i <- l1._1) println(i)
						  println("15-Puzzle")
						  println("Test input:\n "+start2.toString)
						  println("Goal state:\n "+goalState(4))
						  val l2 = Astar(start2, goalState(4), List(Left, Right, Up, Down), misplaced)
						  for(i <- l2._1) println(i)}
				case 3 => {println("8-Puzzle:")
						  println("Test input:\n "+start.toString)
						  println("Goal state:\n "+goalState(3))
					      var l1 = Astar(start, goalState(3), List(Left, Right, Up, Down), maxSwap)
						  for(i <- l1._1) println(i)
						  println("15-Puzzle")
						  println("Test input:\n "+start2.toString)
						  println("Goal state:\n "+goalState(4))
						  val l2 = Astar(start2, goalState(4), List(Left, Right, Up, Down), maxSwap)
						  for(i <- l2._1) println(i)}
				case 4 => {println("8-Puzzle:")
						  println("Test input:\n "+start.toString)
						  println("Goal state:\n "+goalState(3))
					      var l1 = IDAstar(start, goalState(3), List(Left, Right, Up, Down), manhattan)
						  for(i <- l1._1) println(i)
						  println("15-Puzzle")
						  println("Test input:\n "+start2.toString)
						  println("Goal state:\n "+goalState(4))
						  val l2 = IDAstar(start2, goalState(4), List(Left, Right, Up, Down), manhattan)
						  for(i <- l2._1) println(i)}
				case 5 => {println("8-Puzzle:")
						  println("Test input:\n "+start.toString)
						  println("Goal state:\n "+goalState(3))
					      var l1 = IDAstar(start, goalState(3), List(Left, Right, Up, Down), manhattan)
						  for(i <- l1._1) println(i)
						  println("15-Puzzle")
						  println("Test input:\n "+start2.toString)
						  println("Goal state:\n "+goalState(4))
						  val l2 = IDAstar(start2, goalState(4), List(Left, Right, Up, Down), manhattan)
						  for(i <- l2._1) println(i)}
				case 6 => {println("8-Puzzle:")
						  println("Test input:\n "+start.toString)
						  println("Goal state:\n "+goalState(3))
					      var l1 = IDAstar(start, goalState(3), List(Left, Right, Up, Down), manhattan)
						  for(i <- l1._1) println(i)
						  println("15-Puzzle")
						  println("Test input:\n "+start2.toString)
						  println("Goal state:\n "+goalState(4))
						  val l2 = IDAstar(start2, goalState(4), List(Left, Right, Up, Down), manhattan)
						  for(i <- l2._1) println(i)}
				case 7 => {
						   EightPuzzles.testEightPuzzles()
				}
				case 8 => {

				}
				case _ => flag = true
			}
		}

		/*-> Use the same start state and goal state for menu options 1-6 - display start 
		and goal state and the respective paths for options 1-5.*/
		
		/*-> Input lists (list8, list15)of start configurations for 8 puzzle and 15 puzzle 
		problems from new8.txt and new15.txt, respectively.*/
		
		/*-> Part 1: Run A* with all 3 heuristics functions on all start states in list8 
		and record number of nodes expanded, cost of solution, running time on a 
		specific machine, effective branching factor - possibly tabulate these. 
		Calculate and print the average value of metric for each solution depth.*/
		
		/*-> Part 2: Run IDA* on list15 for one of the heuristics functions - 
		not sure what we are supposed to report here, spec says "run a number of 
		test cases on the 15-puzzle", "fine tune your implementation so that it 
		is as fast possible on the Linux machines in our lab", and "report the 
		most difficult problem in terms of solution depth that your implementation 
		can solve in 20 minutes." - I suppose we want to tabulate all the solution 
		depths and their respective times and find the solution that takes 
		closest to 20 minutes to be solved, without crossing the 20 minute limit.
		*/
	}
}