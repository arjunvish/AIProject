package project

import scala.io.Source
import project.Algorithms._

object EightPuzzles {

	def createBoard (s: String): BoardState = {
		var a = s.split(", ")
		var r = 1
		var ct = 0
		var m : Map[(Int, Int),Int] = Map()
		var pos: (Int, Int) = (0, 0)
		for (r <- 1 to 3) {
			for (c <- 1 to 3) {
				if (Integer.parseInt(a(ct)) == 0) {
					pos = (r, c)
				}
				else {
					m += (r, c) -> Integer.parseInt(a(ct))
				}
				ct += 1
			}
		}
		BoardState(Board(3, m), pos)
	}

	def testManhattan (n: Int) {
		var filename = "data/8/level"+Integer.toString(n)+".txt"
		println("Level "+Integer.toString(n))
		var explored = 0.0
		var num = 0
		var t = 0.0
		for (line <- Source.fromFile(filename).getLines()) {
			val b = createBoard(line)
			var t0 = System.nanoTime()
			var temp = Astar(b, goalState(3), List(Left, Right, Up, Down), manhattan)
			var t1 = System.nanoTime()
			t += (t1 - t0)
			explored += temp._2
			num += 1
		}
		var avg = t/num
		println("Average time: "+avg)
		println("Number of explored nodes: "+explored/num)
	}

	def testMisplaced (n: Int ) {
		var filename = "data/8/level"+Integer.toString(n)+".txt"
		println("Level "+Integer.toString(n))
		var explored = 0.0
		var num = 0
		var t = 0.0
		for (line <- Source.fromFile(filename).getLines()) {
			val b = createBoard(line)
			var t0 = System.nanoTime()
			var temp = Astar(b, goalState(3), List(Left, Right, Up, Down), misplaced)
			var t1 = System.nanoTime()
			t += (t1 - t0)
			explored += temp._2
			num += 1
		}
		var avg = t/num
		println("Average time: "+avg)
		println("Number of explored nodes: "+explored/num)
	}

	def testMaxSwap (n: Int ) {
		var filename = "data/8/level"+Integer.toString(n)+".txt"
		println("Level "+Integer.toString(n))
		var explored = 0.0
		var num = 0
		var t = 0.0
		for (line <- Source.fromFile(filename).getLines()) {
			val b = createBoard(line)
			var t0 = System.nanoTime()
			var temp = Astar(b, goalState(3), List(Left, Right, Up, Down), maxSwap)
			var t1 = System.nanoTime()
			t += (t1 - t0)
			explored += temp._2
			num += 1
		}
		var avg = t/num
		println("Average time: "+avg)
		println("Number of explored nodes: "+explored/num)
	}

	def testEightPuzzles() {
		println("\nManhattan\n")
		var t0 = System.nanoTime()
		for (i <- 1 to 20) {
			testManhattan(i)
		}
		var t1 = System.nanoTime()
		println("\nMisplaced Tiles\n")
		t0 = System.nanoTime()
		for (i <- 1 to 20) {
			testMisplaced(i)
		}
		t1 = System.nanoTime()
		println("\nMax-Swap\n")
		t0 = System.nanoTime()
		for (i <- 1 to 20) {
			testMaxSwap(i)
		}
		t1 = System.nanoTime()

	}
}