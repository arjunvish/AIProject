package project

import scala.io.Source

object FifteenPuzzles {

	def createBoard (s: String): BoardState = {
		var a = s.split(", ")
		var r = 1
		var ct = 0
		var m : Map[(Int, Int),Int] = Map()
		var pos: (Int, Int) = (0, 0)
		for (r <- 1 to 4) {
			for (c <- 1 to 4) {
				if (Integer.parseInt(a(ct)) == 0) {
					pos = (r, c)
				}
				else {
					m += (r, c) -> Integer.parseInt(a(ct))
				}
				ct += 1
			}
		}
		BoardState(Board(4, m), pos)
	}

	def testLevel (n: Int) {
		var filename = "data/15/level"+Integer.toString(n)+".txt"
		for (line <- Source.fromFile(filename).getLines()) {
			val b = createBoard(line)
			println(b)
		}
	}
}